email = "conferencemanagement@hotmail.com"
email_password = "Con2019*"
#email = "sebtsu@outlook.com"
#email_password = "barkin2018*"

PAPAERSUBMIT_INITIAL = "Not Submitted"
PAPAERSUBMIT_SUBMITTED = "Submitted"
PAPERSUBMIT_ABSTRACT_REJECTED = "abstract_rejected"
PAPERSUBMIT_ABSTRACT_PENDING = "abstract_pending"
PAPERSUBMIT_ABSTRACT_ACCEPTED = "abstract_accepted"

PAPERSUBMIT_PAPER_REJECTED = "paper_rejected"
PAPERSUBMIT_PAPER_PENDING = "paper_pending"
PAPERSUBMIT_PAPER_ACCEPTED = "paper_accepted"